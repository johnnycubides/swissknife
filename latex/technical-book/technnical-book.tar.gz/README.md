vim.opt.makeprg = "just"
